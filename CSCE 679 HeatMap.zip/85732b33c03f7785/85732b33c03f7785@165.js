function _1(md){return(
md`# CSCE 679 Heat Map

Using D3.js`
)}

function _d3(require){return(
require('d3@7')
)}

function _data(FileAttachment){return(
FileAttachment("temperature_daily.csv").csv()
)}

function _width(){return(
800
)}

function _height(){return(
600
)}

function _margin(){return(
{ top: 50, right: 20, bottom: 50, left: 60 }
)}

function _parsedData(data){return(
data
  .filter(d => d.max_temperature !== "" && d.min_temperature !== "" && !isNaN(+d.max_temperature) && !isNaN(+d.min_temperature))
  .map(d => ({
    date: new Date(d.date),
    year: new Date(d.date).getFullYear(),
    month: new Date(d.date).getMonth() + 1,
    day: new Date(d.date).getDate(),
    tmax: +d.max_temperature,
    tmin: +d.min_temperature
  }))
)}

function _years(parsedData,d3){return(
Array.from(new Set(parsedData.map(d => d.year))).sort(d3.ascending)
)}

function _recentYears(years){return(
years.slice(-10)
)}

function _groupedDailyData(d3,parsedData,recentYears){return(
d3.group(
  parsedData.filter(d => recentYears.includes(d.year)),
  d => d.year,
  d => d.month
)
)}

function _cellWidth(width,margin,recentYears){return(
(width - margin.left - margin.right) / recentYears.length
)}

function _cellHeight(height,margin){return(
(height - margin.top - margin.bottom) / 12
)}

function _tempExtent(d3,parsedData){return(
[
  d3.min(parsedData, d => d.tmin),
  d3.max(parsedData, d => d.tmax)
]
)}

function _monthlyAggregatedData(d3,parsedData,recentYears)
{
  const map = d3.rollup(
    parsedData.filter(d => recentYears.includes(d.year)),
    v => ({
      tmax: d3.max(v, d => d.tmax),
      tmin: d3.min(v, d => d.tmin)
    }),
    d => d.year,
    d => d.month
  )

  return Array.from(map, ([year, months]) =>
    Array.from(months, ([month, values]) => ({
      year,
      month,
      ...values
    }))
  ).flat()
}


function _temperatureType(Inputs){return(
Inputs.radio(["tmax", "tmin"], {label: "Temperature Type", value: "tmax"})
)}

function _colorScale(monthlyAggregatedData,temperatureType,d3)
{
  const temps = monthlyAggregatedData.map(d => d[temperatureType]).filter(d => !isNaN(d))
  return d3.scaleSequential()
    .domain(d3.extent(temps))
    .interpolator(d3.interpolateYlOrRd)
}


function _chart(d3,width,height,recentYears,margin,cellWidth,tempExtent,cellHeight,monthlyAggregatedData,colorScale,temperatureType,tooltip,groupedDailyData)
{
  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)

  const xScale = d3.scaleBand().domain(recentYears).range([margin.left, width - margin.right])
  const yScale = d3.scaleBand().domain(d3.range(1, 13)).range([margin.top, height - margin.bottom])

  // Day scale for mini charts
  const dayScale = d3.scaleLinear().domain([1, 31]).range([0, cellWidth])

  // Temp scale for mini charts
  const tempScale = d3.scaleLinear().domain(tempExtent).range([cellHeight, 0])

  // Add axes
  svg.append("g")
    .attr("transform", `translate(0, ${height - margin.bottom})`)
    .call(d3.axisBottom(xScale).tickFormat(d3.format("d")))

  svg.append("g")
    .attr("transform", `translate(${margin.left}, 0)`)
    .call(d3.axisLeft(yScale).tickFormat(d => d3.timeFormat("%B")(new Date(2000, d - 1, 1))))

  // Heatmap + Line chart
  monthlyAggregatedData.forEach(d => {
    const year = d.year
    const month = d.month
    const x = xScale(year)
    const y = yScale(month)

    if (x === undefined || y === undefined) return // Skip missing data

    const group = svg.append("g").attr("transform", `translate(${x}, ${y})`)

    // Background heatmap color
    group.append("rect")
  .attr("width", cellWidth)
  .attr("height", cellHeight)
  .attr("fill", colorScale(d[temperatureType]))
  .attr("stroke", "#ccc")
  .on("mouseover", function(event) {
    tooltip.style("opacity", 1)
      .html(`
        <strong>Year:</strong> ${year}<br>
        <strong>Month:</strong> ${d3.timeFormat("%B")(new Date(2000, month - 1, 1))}<br>
        <strong>Max Temp:</strong> ${d.tmax}°C<br>
        <strong>Min Temp:</strong> ${d.tmin}°C
      `)
      .style("left", `${event.pageX + 10}px`)
      .style("top", `${event.pageY - 28}px`)
  })
  .on("mouseout", () => tooltip.style("opacity", 0))


    // Mini line charts
    const dailyData = groupedDailyData.get(year)?.get(month)
    if (!dailyData) return

    const lineMax = d3.line()
      .x(d => dayScale(d.day))
      .y(d => tempScale(d.tmax))

    const lineMin = d3.line()
      .x(d => dayScale(d.day))
      .y(d => tempScale(d.tmin))

    group.append("path")
      .datum(dailyData)
      .attr("d", lineMax)
      .attr("fill", "none")
      .attr("stroke", "green")
      .attr("stroke-width", 1)

    group.append("path")
      .datum(dailyData)
      .attr("d", lineMin)
      .attr("fill", "none")
      .attr("stroke", "blue")
      .attr("stroke-width", 1)
  })

  // Legend for heatmap colors
  const legendWidth = 300
  const legendHeight = 10

  const defs = svg.append("defs")
  const linearGradient = defs.append("linearGradient").attr("id", "legend-gradient")

  linearGradient.selectAll("stop")
    .data(d3.ticks(0, 1, 10))
    .enter().append("stop")
    .attr("offset", d => `${d * 100}%`)
    .attr("stop-color", d => colorScale(d3.interpolate(...colorScale.domain())(d)))

  svg.append("rect")
    .attr("x", width - margin.right - legendWidth)
    .attr("y", margin.top / 2)
    .attr("width", legendWidth)
    .attr("height", legendHeight)
    .style("fill", "url(#legend-gradient)")

  const legendScale = d3.scaleLinear()
    .domain(colorScale.domain())
    .range([0, legendWidth])

  svg.append("g")
    .attr("transform", `translate(${width - margin.right - legendWidth}, ${margin.top / 2 + legendHeight})`)
    .call(d3.axisBottom(legendScale).ticks(5))

  return svg.node()
}


function _tooltip(d3)
{
  const div = d3.select("body").append("div")
    .style("position", "absolute")
    .style("text-align", "left")
    .style("padding", "8px")
    .style("font", "12px sans-serif")
    .style("background", "rgba(0, 0, 0, 0.7)")
    .style("color", "white")
    .style("border", "0px")
    .style("border-radius", "8px")
    .style("pointer-events", "none")
    .style("opacity", 0)

  return div
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["temperature_daily.csv", {url: new URL("./files/b14b4f364b839e451743331d515692dfc66046924d40e4bff6502f032bd591975811b46cb81d1e7e540231b79a2fa0f4299b0e339e0358f08bef900595e74b15.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer("parsedData")).define("parsedData", ["data"], _parsedData);
  main.variable(observer("years")).define("years", ["parsedData","d3"], _years);
  main.variable(observer("recentYears")).define("recentYears", ["years"], _recentYears);
  main.variable(observer("groupedDailyData")).define("groupedDailyData", ["d3","parsedData","recentYears"], _groupedDailyData);
  main.variable(observer("cellWidth")).define("cellWidth", ["width","margin","recentYears"], _cellWidth);
  main.variable(observer("cellHeight")).define("cellHeight", ["height","margin"], _cellHeight);
  main.variable(observer("tempExtent")).define("tempExtent", ["d3","parsedData"], _tempExtent);
  main.variable(observer("monthlyAggregatedData")).define("monthlyAggregatedData", ["d3","parsedData","recentYears"], _monthlyAggregatedData);
  main.variable(observer("viewof temperatureType")).define("viewof temperatureType", ["Inputs"], _temperatureType);
  main.variable(observer("temperatureType")).define("temperatureType", ["Generators", "viewof temperatureType"], (G, _) => G.input(_));
  main.variable(observer("colorScale")).define("colorScale", ["monthlyAggregatedData","temperatureType","d3"], _colorScale);
  main.variable(observer("chart")).define("chart", ["d3","width","height","recentYears","margin","cellWidth","tempExtent","cellHeight","monthlyAggregatedData","colorScale","temperatureType","tooltip","groupedDailyData"], _chart);
  main.variable(observer("tooltip")).define("tooltip", ["d3"], _tooltip);
  return main;
}
